from distutils.core import setup

setup(name='src', version='1.0')
